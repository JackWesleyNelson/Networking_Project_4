I did parts I and II.

Since I didn't do part III I didn't choose an application layer protocol to work on.

The source files need to build my program are resultsC.cc, resultsC.h, project4.cc, project4.h which can be compiled with the Makefile.
